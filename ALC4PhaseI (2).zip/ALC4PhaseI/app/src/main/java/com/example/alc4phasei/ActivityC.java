package com.example.alc4phasei;

import android.content.ClipData;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toolbar;

public class ActivityC extends AppCompatActivity {

    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        imageView = (ImageView) findViewById(R.id.imageView_mypic);

        imageView.getAdjustViewBounds();
        imageView.getMaxHeight();
        imageView.getScaleType();

        imageView.setImageResource(R.drawable.beeoh);


    }










    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_back) {
           finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
